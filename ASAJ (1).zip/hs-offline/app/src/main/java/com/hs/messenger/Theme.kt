package com.hs.messenger

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object HSColors {
    val Teal = Color(0xFF075E54)
    val Green = Color(0xFF25D366)
    val Sent = Color(0xFFDCF8C6)
    val Received = Color.White
    val ChatBg = Color(0xFFECE5DD)
}

@Composable
fun HSTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(primary = HSColors.Teal, secondary = HSColors.Green, onPrimary = Color.White),
        content = content
    )
}

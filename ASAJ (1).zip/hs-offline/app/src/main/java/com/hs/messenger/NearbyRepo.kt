package com.hs.messenger

import android.Manifest
import android.content.Context
import android.os.Build
import com.google.android.gms.nearby.Nearby
import com.google.android.gms.nearby.connection.AdvertisingOptions
import com.google.android.gms.nearby.connection.ConnectionInfo
import com.google.android.gms.nearby.connection.ConnectionLifecycleCallback
import com.google.android.gms.nearby.connection.ConnectionResolution
import com.google.android.gms.nearby.connection.ConnectionsClient
import com.google.android.gms.nearby.connection.DiscoveredEndpointInfo
import com.google.android.gms.nearby.connection.DiscoveryOptions
import com.google.android.gms.nearby.connection.EndpointDiscoveryCallback
import com.google.android.gms.nearby.connection.Payload
import com.google.android.gms.nearby.connection.PayloadCallback
import com.google.android.gms.nearby.connection.PayloadTransferUpdate
import com.google.android.gms.nearby.connection.Strategy
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import org.json.JSONObject
import java.util.UUID

data class NearbyMsg(
    val id: String,
    val name: String,
    val text: String,
    val time: Long,
    val mine: Boolean
)

/**
 * Offline chat with no internet, using Google Nearby Connections
 * (Bluetooth + BLE + Wi-Fi Direct, picked automatically).
 *
 * Everyone nearby who opens the Offline screen joins one shared room.
 * Messages are relayed from phone to phone, so the room can be larger than one radio range.
 */
object NearbyRepo {
    private const val SERVICE_ID = "com.hs.messenger.offline"

    private val _peers = MutableStateFlow<Map<String, String>>(emptyMap()) // endpointId -> name
    private val _messages = MutableStateFlow<List<NearbyMsg>>(emptyList())
    val peers: StateFlow<Map<String, String>> = _peers
    val messages: StateFlow<List<NearbyMsg>> = _messages
    val running = MutableStateFlow(false)
    val status = MutableStateFlow("Off")

    private var client: ConnectionsClient? = null
    private var myName = ""
    private var myTag = ""
    private val seen = HashSet<String>()
    private val names = HashMap<String, String>()   // endpointId -> display name during handshake

    fun requiredPermissions(): Array<String> {
        // Location is needed on every Android version for Bluetooth/Wi-Fi discovery.
        val base = arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
        return when {
            Build.VERSION.SDK_INT >= 33 -> base + arrayOf(
                Manifest.permission.BLUETOOTH_ADVERTISE, Manifest.permission.BLUETOOTH_CONNECT,
                Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.NEARBY_WIFI_DEVICES
            )
            Build.VERSION.SDK_INT >= 31 -> base + arrayOf(
                Manifest.permission.BLUETOOTH_ADVERTISE, Manifest.permission.BLUETOOTH_CONNECT,
                Manifest.permission.BLUETOOTH_SCAN
            )
            else -> base
        }
    }

    /** Call after the permissions above are granted. */
    fun start(context: Context, name: String) {
        if (running.value) return
        myName = name.ifBlank { "User" }
        myTag = UUID.randomUUID().toString().take(6)
        val c = Nearby.getConnectionsClient(context.applicationContext)
        client = c
        val advName = "$myName#$myTag"

        c.startAdvertising(
            advName, SERVICE_ID, connectionCallback,
            AdvertisingOptions.Builder().setStrategy(Strategy.P2P_CLUSTER).build()
        ).addOnFailureListener { status.value = "Advertising failed: ${it.message}" }

        c.startDiscovery(
            SERVICE_ID, discoveryCallback,
            DiscoveryOptions.Builder().setStrategy(Strategy.P2P_CLUSTER).build()
        ).addOnFailureListener { status.value = "Discovery failed: ${it.message}" }

        running.value = true
        status.value = "Searching for nearby phones…"
    }

    fun stop() {
        client?.apply { stopAdvertising(); stopDiscovery(); stopAllEndpoints() }
        client = null
        _peers.value = emptyMap(); _messages.value = emptyList()
        seen.clear(); names.clear()
        running.value = false; status.value = "Off"
    }

    fun send(text: String) {
        val t = text.trim().take(4000)
        if (t.isEmpty()) return
        val msg = NearbyMsg(UUID.randomUUID().toString(), myName, t, System.currentTimeMillis(), true)
        seen.add(msg.id)
        _messages.value = _messages.value + msg
        broadcast(encode(msg).toByteArray(), except = null)
    }

    // ---------------------------------------------------------------- internals

    private fun encode(m: NearbyMsg) = JSONObject()
        .put("i", m.id).put("n", m.name).put("t", m.text).put("ts", m.time).toString()

    private fun broadcast(bytes: ByteArray, except: String?) {
        val targets = _peers.value.keys.filter { it != except }
        if (targets.isNotEmpty()) client?.sendPayload(targets, Payload.fromBytes(bytes))
    }

    private fun tagOf(endpointName: String) = endpointName.substringAfterLast('#', "")
    private fun nameOf(endpointName: String) = endpointName.substringBeforeLast('#')

    private val discoveryCallback = object : EndpointDiscoveryCallback() {
        override fun onEndpointFound(id: String, info: DiscoveredEndpointInfo) {
            // Only the phone with the smaller tag starts the connection, so two phones
            // never request each other at the same time.
            if (myTag < tagOf(info.endpointName)) {
                client?.requestConnection("$myName#$myTag", id, connectionCallback)
            }
        }
        override fun onEndpointLost(id: String) {}
    }

    private val connectionCallback = object : ConnectionLifecycleCallback() {
        override fun onConnectionInitiated(id: String, info: ConnectionInfo) {
            names[id] = nameOf(info.endpointName)
            client?.acceptConnection(id, payloadCallback)
        }

        override fun onConnectionResult(id: String, result: ConnectionResolution) {
            if (result.status.isSuccess) {
                _peers.value = _peers.value + (id to (names[id] ?: "Friend"))
                status.value = "Connected: ${_peers.value.size} nearby"
            } else names.remove(id)
        }

        override fun onDisconnected(id: String) {
            _peers.value = _peers.value - id
            names.remove(id)
            status.value = if (_peers.value.isEmpty()) "Searching for nearby phones…"
            else "Connected: ${_peers.value.size} nearby"
        }
    }

    private val payloadCallback = object : PayloadCallback() {
        override fun onPayloadReceived(id: String, payload: Payload) {
            val bytes = payload.asBytes() ?: return
            try {
                val o = JSONObject(String(bytes))
                val msgId = o.getString("i")
                if (!seen.add(msgId)) return                      // already have it
                _messages.value = _messages.value + NearbyMsg(
                    msgId, o.getString("n"), o.getString("t"), o.getLong("ts"), false
                )
                broadcast(bytes, except = id)                      // relay to the others
            } catch (_: Exception) {}
        }

        override fun onPayloadTransferUpdate(id: String, update: PayloadTransferUpdate) {}
    }
}

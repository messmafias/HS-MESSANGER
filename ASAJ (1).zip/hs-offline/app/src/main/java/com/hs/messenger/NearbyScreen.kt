package com.hs.messenger

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NearbyScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val running by NearbyRepo.running.collectAsState()
    val status by NearbyRepo.status.collectAsState()
    val peers by NearbyRepo.peers.collectAsState()
    val msgs by NearbyRepo.messages.collectAsState()
    val prefs = remember { context.getSharedPreferences("hs", 0) }
    var name by remember { mutableStateOf(prefs.getString("name", "") ?: "") }
    var text by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    val permLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        if (result.values.all { it }) { prefs.edit().putString("name", name.trim()).apply(); NearbyRepo.start(context, name.trim()) }
        else NearbyRepo.status.value = "Permission needed to find nearby phones"
    }

    DisposableEffect(Unit) { onDispose { NearbyRepo.stop() } }
    BackHandler { onBack() }
    LaunchedEffect(msgs.size) { if (msgs.isNotEmpty()) listState.animateScrollToItem(msgs.lastIndex) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Offline (Nearby)", fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
                        Text(status, fontSize = 12.sp)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
                },
                actions = {
                    if (running) TextButton(onClick = { NearbyRepo.stop() }) { Text("Stop", color = Color.White) }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = HSColors.Teal, titleContentColor = Color.White,
                    navigationIconContentColor = Color.White, actionIconContentColor = Color.White
                )
            )
        }
    ) { pad ->
        if (!running) {
            Column(
                Modifier.fillMaxSize().padding(pad).padding(24.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("Chat with phones near you, no internet needed.", fontSize = 16.sp)
                Spacer(Modifier.height(6.dp))
                Text("Uses Bluetooth / Wi-Fi Direct. Ask friends to open this screen too.", fontSize = 13.sp, color = Color.Gray)
                Spacer(Modifier.height(20.dp))
                OutlinedTextField(
                    value = name, onValueChange = { name = it }, label = { Text("Your name") },
                    singleLine = true, modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(12.dp))
                Button(
                    onClick = { permLauncher.launch(NearbyRepo.requiredPermissions()) },
                    enabled = name.isNotBlank(),
                    colors = ButtonDefaults.buttonColors(containerColor = HSColors.Green),
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Start") }
                if (status != "Off") Text(status, color = Color.Red, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
            }
        } else {
            Column(Modifier.fillMaxSize().padding(pad).background(HSColors.ChatBg).imePadding()) {
                if (peers.isNotEmpty()) {
                    Text(
                        "Nearby: " + peers.values.joinToString(", "),
                        fontSize = 12.sp, color = HSColors.Teal,
                        modifier = Modifier.fillMaxWidth().background(Color.White).padding(8.dp)
                    )
                }
                LazyColumn(
                    state = listState, modifier = Modifier.weight(1f).fillMaxWidth(),
                    contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(msgs, key = { it.id }) { m ->
                        Box(Modifier.fillMaxWidth(), contentAlignment = if (m.mine) Alignment.CenterEnd else Alignment.CenterStart) {
                            Column(
                                Modifier.widthIn(max = 280.dp)
                                    .background(if (m.mine) HSColors.Sent else HSColors.Received, RoundedCornerShape(12.dp))
                                    .padding(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                if (!m.mine) Text(m.name, fontSize = 12.sp, color = HSColors.Teal, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
                                Text(m.text, fontSize = 16.sp)
                            }
                        }
                    }
                }
                Row(Modifier.fillMaxWidth().background(Color(0xFFF0F2F5)).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = text, onValueChange = { text = it }, placeholder = { Text("Message") },
                        modifier = Modifier.weight(1f), shape = RoundedCornerShape(24.dp), maxLines = 4
                    )
                    IconButton(onClick = { NearbyRepo.send(text); text = "" }, enabled = text.isNotBlank()) {
                        Icon(Icons.AutoMirrored.Filled.Send, "Send", tint = HSColors.Teal)
                    }
                }
            }
        }
    }
}
